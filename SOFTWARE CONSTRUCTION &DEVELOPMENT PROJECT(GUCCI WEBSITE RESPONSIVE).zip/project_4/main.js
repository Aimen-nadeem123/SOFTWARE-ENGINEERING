// Import Firebase SDK (Modular Imports)
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import { getFirestore, collection, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";

// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyCTfQmPSm3zGA_D4jIw7exgQxioOud6HYM",
    authDomain: "my-website-project-86e81.firebaseapp.com",
    projectId: "my-website-project-86e81",
    storageBucket: "my-website-project-86e81.appspot.com",
    messagingSenderId: "290489872421",
    appId: "1:290489872421:web:4901d494c071ec77130fcc"
};

// Initialize Firebase App
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Submit Form Function
document.getElementById("contact-form").addEventListener("submit", async function (event) {
    event.preventDefault();

    // Get form values
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const number = document.getElementById("number").value;
    const qualification = document.getElementById("qualification").value;
    const message = document.getElementById("message").value;
    const gender = document.querySelector('input[name="gender"]:checked')?.value;

    if (!gender) {
        alert("Please select your gender.");
        return;
    }

    try {
        // Add form data to Firestore
        await addDoc(collection(db, "contactForms"), {
            name: name,
            email: email,
            number: number,
            qualification: qualification,
            message: message,
            gender: gender,
            timestamp: serverTimestamp()
        });

        alert("Form submitted successfully!");
        document.getElementById("contact-form").reset();
    } catch (error) {
        console.error("Error submitting form:", error);
        alert("Error submitting form. Please check the console for details.");
    }
});
