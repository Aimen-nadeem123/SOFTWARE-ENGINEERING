// Wait for the DOM to fully load
window.addEventListener('DOMContentLoaded', () => {
    
    // 1. Sticky Navbar on Scroll
    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.style.position = 'fixed';
            navbar.style.top = '0';
            navbar.style.width = '100%';
            navbar.style.zIndex = '1000';
            navbar.style.backgroundColor = 'black';
        } else {
            navbar.style.position = 'relative';
            navbar.style.backgroundColor = 'transparent';
        }
    });

    // 2. Smooth Scrolling for Navigation Links (Only for in-page links)
    const navLinks = document.querySelectorAll('#navbar ul li a');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const href = e.target.getAttribute('href');
            if (href.startsWith('#')) { // Check if the link is for an in-page section
                e.preventDefault();
                const targetId = href.substring(1);
                const targetElement = document.getElementById(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - navbar.offsetHeight,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });

    // 3. Buy Now Button Click
    const buyNowButton = document.querySelector('#home .btn');
    if (buyNowButton) {
        buyNowButton.addEventListener('click', () => {
            alert('Thank you for your interest! This feature will be available soon.');
        });
    }

    // 4. Hover Effect on Service Boxes
    const serviceBoxes = document.querySelectorAll('.services .box');
    serviceBoxes.forEach(box => {
        box.addEventListener('mouseover', () => {
            box.style.transform = 'scale(1.05)';
            box.style.transition = 'all 0.3s ease';
        });
        box.addEventListener('mouseout', () => {
            box.style.transform = 'scale(1)';
        });
    });

    // 5. Scroll-to-top Button
    const scrollToTopButton = document.createElement('button');
    scrollToTopButton.innerText = '⬆️';
    scrollToTopButton.style.position = 'fixed';
    scrollToTopButton.style.bottom = '20px';
    scrollToTopButton.style.right = '20px';
    scrollToTopButton.style.padding = '10px 15px';
    scrollToTopButton.style.fontSize = '18px';
    scrollToTopButton.style.display = 'none';
    scrollToTopButton.style.backgroundColor = 'black';
    scrollToTopButton.style.color = 'white';
    scrollToTopButton.style.border = 'none';
    scrollToTopButton.style.borderRadius = '5px';
    scrollToTopButton.style.cursor = 'pointer';
    document.body.appendChild(scrollToTopButton);

    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollToTopButton.style.display = 'block';
        } else {
            scrollToTopButton.style.display = 'none';
        }
    });

    scrollToTopButton.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // 6. Dynamic Year in Footer
    const footer = document.querySelector('footer .center');
    if (footer) {
        const currentYear = new Date().getFullYear();
        footer.innerHTML = `Copyright &copy; www.GUCCI.com. All rights reserved. ${currentYear}`;
    }
});
