from django.shortcuts import render
import pandas as pd
from .forms import DatasetForm
import matplotlib.pyplot as plt
from io import BytesIO
import base64
import os
from django.conf import settings 

def handle_uploaded_file(file):
    file_path = os.path.join(settings.MEDIA_ROOT, file.name)
    with open(file_path, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)


# File Upload View
def upload_dataset(request):
    if request.method == 'POST':
        form = DatasetForm(request.POST, request.FILES)
        if form.is_valid():
            handle_uploaded_file(request.FILES['dataset'])
            return render(request, 'success.html')
    else:
        form = DatasetForm()
    return render(request, 'upload.html', {'form': form})

# Dataset Overview View
file_path = os.path.join(settings.MEDIA_ROOT, 'AIDS DATASET.csv')


def dataset_overview(request):
    dataset = pd.read_csv(file_path)
    head = dataset.head().to_html(classes='table table-striped')
    stats = dataset.describe().to_html(classes='table table-bordered')
    return render(request, 'dataset_overview.html', {'head': head, 'stats': stats})

# Plot Loss View
def plot_loss(request):
    epochs = [1, 2, 3, 4, 5]
    loss = [0.5, 0.4, 0.3, 0.2, 0.1]

    plt.figure()
    plt.plot(epochs, loss, marker='o')
    plt.title("Epochs vs Loss")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")

    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    graph = base64.b64encode(buffer.getvalue()).decode()
    buffer.close()

    return render(request, 'plot.html', {'graph': graph})

# Home View
def home(request):
    return render(request, 'home.html')
