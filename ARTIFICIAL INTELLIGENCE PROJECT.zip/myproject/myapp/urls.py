from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Home view
    path('upload/', views.upload_dataset, name='upload_dataset'),  # Upload view
    path('plot_loss/', views.plot_loss, name='plot_loss'),  # Plot Loss view
    path('overview/', views.dataset_overview, name='dataset_overview'),  # Dataset Overview view
]
