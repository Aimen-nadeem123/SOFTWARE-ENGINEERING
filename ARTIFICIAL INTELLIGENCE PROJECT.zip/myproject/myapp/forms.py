from django import forms

class DatasetForm(forms.Form):
    dataset = forms.FileField()
