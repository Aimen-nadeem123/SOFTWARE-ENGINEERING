# Create your models here.
from django.db import models

class Dataset(models.Model):
    name = models.CharField(max_length=255)
    upload_date = models.DateTimeField(auto_now_add=True)

class Metrics(models.Model):
    technique = models.CharField(max_length=255)
    mse = models.FloatField()
    epochs = models.IntegerField()
    loss = models.FloatField()
