from flask import Flask, request, render_template, redirect, url_for
from pymongo import MongoClient
import os

app = Flask(__name__)

# MongoDB connection with authentication using environment variables
mongo_user = os.getenv('MONGO_USER')
mongo_password = os.getenv('MONGO_PASSWORD')

# Connection string with authentication credentials
client = MongoClient(f"mongodb://{mongo_user}:{mongo_password}@mongo-service:27017/")
db = client["my_data"]  # Database name
collection = db["enteries"]  # Collection name

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        # Get the form data
        name = request.form["name"]
        email = request.form["email"]
        number = request.form["number"]
        qualification = request.form["qualification"]
        message = request.form["message"]
        gender = request.form["gender"]

        # Insert data into MongoDB if required fields are present
        if name and email and number and qualification and message and gender:
            collection.insert_one({
                "name": name,
                "email": email,
                "number": number,
                "qualification": qualification,
                "message": message,
                "gender": gender
            })
            return redirect(url_for("success"))
    return render_template("contact.html")

@app.route("/success")
def success():
    return "Data successfully added to MongoDB!"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
