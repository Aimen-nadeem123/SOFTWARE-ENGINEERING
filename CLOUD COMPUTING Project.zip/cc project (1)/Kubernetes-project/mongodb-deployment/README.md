kubernetes-microservices-project/
│
├── frontend_1/
│   ├── Dockerfile
│   ├── app.py
│   ├── templates/
│   │   └── index.html
│   │
│   └── kubernetes/
│       └── frontend-deployment.yaml
│
├── frontend_2/
│   ├── Dockerfile
│   ├── app.py
│   ├── templates/
│   │   └── index.html
│   │
│   └── kubernetes/
│       └── frontend-deployment.yaml
│
├── mongodb/
│   ├── mongo-config.yaml
│   ├── mongo-secret.yaml
│   ├── mongo-deployment.yaml
│
└── README.md

Step 1: Build Docker Images
Create Docker images for both front-end services.

Frontend Data Entry:

cd frontend_1
docker build -t frontend-1 .
docker push aimenkhan123/frontend-1

Frontend Data Display:

cd frontend_2
docker build -t aimenkhan123/frontend-2 .
docker push aimenkhan123/frontend-2

Step 2: Deploy MongoDB Backend
Apply MongoDB Configuration Files:

kubectl apply -f mongodb/mongo-config.yaml
kubectl apply -f mongodb/mongo-secret.yaml
kubectl apply -f mongodb/mongo-deployment.yaml

Step 3: Deploy Front-End Services

kubectl apply -f kubernetes/frontend-deployment.yaml

Step 4: Verify All Deployments and Services

Check that all pods, services, and deployments are running:

kubectl get deployments
kubectl get pods
kubectl get services

Step 5: To access a service as Internal Service In cluster

minikube service frontend-1-service
minikube service frontend-2-service

Step 6: To access data-display as External Service

kubectl port-forward services/frontend-2-service 5001:5001