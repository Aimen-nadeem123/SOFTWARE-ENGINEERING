from flask import Flask, render_template
from pymongo import MongoClient
import os

app = Flask(__name__)

# MongoDB connection with authentication using environment variables
mongo_user = os.getenv('MONGO_USER')
mongo_password = os.getenv('MONGO_PASSWORD')

# Ensure the environment variables are set
if not mongo_user or not mongo_password:
    raise ValueError("MongoDB username and password must be set as environment variables.")

# MongoDB connection string with authentication credentials
client = MongoClient(f"mongodb://{mongo_user}:{mongo_password}@mongo-service:27017/")

# Database and collection names
db = client["my_data"]
collection = db["enteries"]

@app.route("/")
def index():
    try:
        # Fetch all records from the collection
        data = list(collection.find())  # Convert cursor to list for easier handling in templates

        # Convert _id to string to prevent errors in templates
        for item in data:
            item["_id"] = str(item["_id"])

        return render_template("display.html", data=data)  # Use index.html template

    except Exception as e:
        # Handle MongoDB connection or query error
        return f"An error occurred: {e}"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)

